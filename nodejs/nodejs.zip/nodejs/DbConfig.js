module.exports = Object.freeze({
    DB_HOST : '',
    DB_USER : 'expense',
    DB_PWD : 'ExpenseApp@1',
    DB_DATABASE : 'transactions'
});
